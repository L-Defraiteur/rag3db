// Généré par cmake/build_id.cmake à chaque bâti ; ne pas éditer.
#pragma once

#define RAG3DB_BUILD_ID "rag3db-build-888c81825e4cd6556261233f0e238af3b95375c9-Release-p12-v11-g17-s18-rcOFF-stOFF-asanOFF-tsanOFF-ubsanOFF"
