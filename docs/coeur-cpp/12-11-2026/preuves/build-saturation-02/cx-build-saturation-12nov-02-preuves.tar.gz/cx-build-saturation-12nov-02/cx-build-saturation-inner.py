import hashlib,json,os,shlex,shutil,subprocess,sys,time
from pathlib import Path
source,build,out,reference,recipe=map(Path,sys.argv[1:6]);deadline=float(sys.argv[6]);gold=out/'preflight-golden'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def run(argv,name):
 p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=max(1,deadline-time.monotonic()))
 (out/name).write_bytes(p.stdout)
 if p.returncode:raise RuntimeError(f'{name}: code {p.returncode}, premier echec stop')
 return p.stdout
assert os.statvfs(source).f_flag & os.ST_RDONLY
assert os.statvfs(reference).f_flag & os.ST_RDONLY
os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['GIT_ALLOW_PROTOCOL']='';os.environ['CCACHE_DISABLE']='1'
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert commit=='35ea70d3a4a5cc4917586de02f6bfc862c76a02c'
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
v=json.loads(recipe.read_text());argv=[s.replace('{private_source}',str(source)).replace('{private_build}',str(build)) for s in v['build']['configure_argv']]
argv+=['-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DAUTO_UPDATE_GRAMMAR=OFF','-DCCACHE_PROGRAM:FILEPATH=','-DSINGLE_THREADED=OFF','-DENABLE_MALLOC_BUFFER_MANAGER=OFF','-DUSE_STD_FORMAT=OFF']
write('configure-argv.json',argv);run(argv,'configure.log')
for name in ['CMakeCache.txt','compile_commands.json','build.ninja']:(out/name).write_bytes((build/name).read_bytes())

def norm(items,root,binary):
 result={}
 for item in items:
  f=Path(item['file']);args=item.get('arguments') or shlex.split(item['command']);clean=[];i=0
  while i<len(args):
   t=args[i]
   if t in ['-o','-c','-MF','-MT']:i+=2;continue
   if t=='-MD':i+=1;continue
   clean.append(t.replace(str(binary),'<BUILD>').replace(str(root),'<SOURCE>'));i+=1
  if f.is_relative_to(binary):key='<GENERATED>/'+str(f.relative_to(binary))
  elif f.is_relative_to(root):key=str(f.relative_to(root))
  else:key='<EXTERNAL>/'+str(f)
  result[key]=clean
 return result
old=json.loads((gold/'compile_commands.json').read_text());new=json.loads((build/'compile_commands.json').read_text())
oldbuild=Path(old[0]['directory']);oldroot=oldbuild.parent/'source'
a,b=norm(old,oldroot,oldbuild),norm(new,source,build)
changes={k:{'preflight':a.get(k),'build':b.get(k)} for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}
config=build/'src/include/common/system_config.h';sameconfig=config.read_bytes()==(gold/'private-system_config.h').read_bytes()
missing_sources=[i['file'] for i in new if not Path(i['file']).is_file()]
recheck={'source_commit':commit,'preflight_compile_commands_sha256':sha(gold/'compile_commands.json'),'candidate_compile_commands_sha256':sha(build/'compile_commands.json'),'normalized_commands_count':len(b),'normalized_changes':changes,'system_config_identical':sameconfig,'system_config_sha256':sha(config),'missing_sources':missing_sources,'source_readonly':True,'scenario_authorized':False}
write('revalidation-avant-build.json',recheck)
if changes or not sameconfig or missing_sources:raise RuntimeError('preflight revalidation refusee, pas de build')
for target in ['concurrence_test','rag3db_vector_extension','rag3db_geo_extension']:run(['ninja','-C',str(build),'-t','commands',target],f'ninja-{target}-commands.txt')
cmd=['cmake','--build',str(build),'--target','concurrence_test','rag3db_vector_extension','rag3db_geo_extension','-j','8']
write('build-argv.json',cmd)
started=time.monotonic()
try:run(cmd,'build.log')
except BaseException as e:
 write('premier-echec.json',{'phase':'build','type':type(e).__name__,'error':str(e),'source_commit':commit,'elapsed_build_s':time.monotonic()-started,'automatic_retry':False})
 raise
write('build-result.json',{'returncode':0,'elapsed_build_s':time.monotonic()-started,'targets':cmd[4:7],'scenario_run':False})
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
# Package is fresh and never mixed with the old 0511 archive. Size hard checked
# before copies; only package files listed in final manifest are runtime candidates.
package=out/'package';assert not package.exists();package.mkdir()
items=[(build/'src/librag3db.a','lib/librag3db.a'),(build/'test/transaction/concurrence/concurrence_test','bin/concurrence_test'),(source/'extension/vector/build/libvector.rag3db_extension','extension/vector/build/libvector.rag3db_extension'),(source/'extension/geo/build/libgeo.rag3db_extension','extension/geo/build/libgeo.rag3db_extension')]
for root,target in [(source/'src/include','headers-source'),(build/'src/include','headers-generes')]:
 for p in root.rglob('*'):
  if p.is_file():items.append((p,str(Path(target)/p.relative_to(root))))
for p in (build/'third_party').rglob('*.a'):items.append((p,str(Path('tiers')/p.relative_to(build/'third_party'))))
assert all(p.is_file() for p,_ in items)
size=sum(p.stat().st_size for p,_ in items);assert size<=512*1024**2
manifest=[]
for p,name in items:
 if time.monotonic()>=deadline:raise RuntimeError('budget atteint avant sauvegarde')
 dest=package/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 digest=sha(p);assert sha(dest)==digest
 manifest.append({'path':name,'bytes':p.stat().st_size,'sha256':digest})
for name in ['bin/concurrence_test','extension/vector/build/libvector.rag3db_extension','extension/geo/build/libgeo.rag3db_extension']:
 run(['readelf','-h','-d','-n',str(package/name)],'elf-'+Path(name).name+'.txt')
headers={name:(package/'headers-generes/common'/name).read_text() for name in ['system_config.h','build_id.h']}
write('manifest.json',{'source_commit':commit,'source_root_at_build':str(source),'build_root':str(build),'compile_commands_sha256':sha(build/'compile_commands.json'),'cache_sha256':sha(build/'CMakeCache.txt'),'build_id_header':headers['build_id.h'],'system_config_header':headers['system_config.h'],'files':manifest,'package_bytes':size,'scenario_run':False,'runtime_authorized':False})
write('SHA256.json',{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='SHA256.json'})
