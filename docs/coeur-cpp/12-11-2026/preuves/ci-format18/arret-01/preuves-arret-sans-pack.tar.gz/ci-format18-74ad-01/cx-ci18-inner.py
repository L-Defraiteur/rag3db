import hashlib,json,os,shutil,signal,subprocess,sys,time,xml.etree.ElementTree as ET,re
from pathlib import Path
source,build,out,recipe=map(Path,sys.argv[1:5]);deadline=float(sys.argv[5]);v=json.loads(recipe.read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1024**2),b''):h.update(x)
 return h.hexdigest()
def write(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def run(argv,name,timeout,env=None,cwd=None):
 start=time.monotonic();p=None
 with (out/name).open('wb') as log:
  try:
   p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=cwd,start_new_session=True)
   code=p.wait(timeout=min(timeout,max(1,deadline-time.monotonic())))
  except BaseException:
   if p and p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
   raise
 write(name+'.result.json',{'argv':argv,'pid':p.pid,'returncode':code,'elapsed_s':time.monotonic()-start,'waited':True})
 if code:raise RuntimeError(f'{name} premier echec code{code}')
 return code
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip();assert commit==v['source_commit']
assert os.statvfs(source).f_flag & os.ST_RDONLY
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
for path in ['test/transaction/quarantine_released_diagnostic.cpp','src/common/private_saturation_capture.cpp']:assert not (source/path).exists()
os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['CCACHE_DISABLE']='1';os.environ['GIT_ALLOW_PROTOCOL']=''
argv=[s.replace('{source}',str(source)).replace('{build}',str(build)) for s in v['configure_argv']]
write('configure-argv.json',argv);run(argv,'configure.log',120)
for name in ['CMakeCache.txt','compile_commands.json','build.ninja']:(out/name).write_bytes((build/name).read_bytes())
commands=json.loads((build/'compile_commands.json').read_text());assert all('quarantine_released_diagnostic' not in i['file'] and 'private_saturation_capture' not in i['file'] for i in commands)
write('source-attestation.json',{'commit':commit,'source_readonly':True,'no_private_diagnostic_source':True,'compile_units':len(commands),'source_clean':True,'distributed_lib_untouched':True})
for target in ['transaction_test','rag3db_shell','rag3db_vector_extension','rag3db_geo_extension']:run(['ninja','-C',str(build),'-t','commands',target],'ninja-'+target+'.txt',60)
phase='build'
try:
 argv=[x.replace('{build}',str(build)) for x in v['build_argv']];run(argv,'build.log',v['build_timeout_s'])
 binfile=build/'test/transaction/transaction_test';shell=build/'tools/shell/rag3db'
 files={'transaction_test':binfile,'rag3db_shell':shell,'engine.a':build/'src/librag3db.a','vector':source/'extension/vector/build/libvector.rag3db_extension','geo':source/'extension/geo/build/libgeo.rag3db_extension'}
 for p in files.values():assert p.is_file()
 bid=(build/'src/include/common/build_id.h').read_text();marker=re.search(r'RAG3DB_BUILD_ID "([^"]+)"',bid)[1]
 for k in ['transaction_test','rag3db_shell','vector','geo']:assert marker.encode() in files[k].read_bytes()
 pre={name:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}
 write('manifest-avant-test.json',{'source_commit':commit,'build_id_header':bid,'system_config_header':(build/'src/include/common/system_config.h').read_text(),'files':pre,'cache_sha256':sha(build/'CMakeCache.txt'),'compile_commands_sha256':sha(build/'compile_commands.json')})
 tmp=build.parent/'test-tmp';work=build.parent/'test-work';tmp.mkdir();work.mkdir()
 env={k:s.replace('{scratch}',str(build.parent)) for k,s in v['test_environment'].items()};write('transaction-environment.json',env)
 argv=[s.replace('{build}',str(build)).replace('{output}',str(out)) for s in v['test_argv']];write('transaction-argv.json',argv)
 # Nested RO mounts freeze the compiled source/extensions/build for the suite.
 cmd=['bwrap','--unshare-user','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--ro-bind',str(source),str(source),'--ro-bind',str(build),str(build),'--bind',str(tmp),str(tmp),'--bind',str(work),str(work),'--bind',str(out),str(out),'--chdir',str(work)]
 for ext in ['vector','geo']:
  p=str(source/'extension'/ext/'build');cmd+=['--ro-bind',p,p]
 cmd+=['/usr/bin/env','-i',*[k+'='+val for k,val in env.items()],*argv]
 phase='transaction_test';run(cmd,'transaction.log',v['test_timeout_s'])
 tree=ET.parse(out/'transaction.xml');cases=list(tree.getroot().iter('testcase'));executed=[c for c in cases if c.attrib.get('status')=='run'];failures=[{'case':c.attrib,'failure':[f.attrib for f in c.findall('failure')]} for c in cases if c.find('failure') is not None];skips=[{'case':c.attrib,'reason':c.find('skipped').attrib} for c in cases if c.find('skipped') is not None];disabled=[c.attrib for c in cases if c.attrib.get('status')=='notrun'];log=(out/'transaction.log').read_text(errors='replace');selected=re.search(r'\[==========\] Running (\d+) tests?',log)
 write('transaction-result.json',{'xml_root':tree.getroot().attrib,'selected_stdout':int(selected[1]) if selected else None,'cases_xml':len(cases),'executed_including_skipped':len(executed),'failures':failures,'skipped':skips,'disabled_or_notrun':disabled,'actual_tests_nonempty':bool(executed),'filter':None,'repeats':1})
 assert selected and int(selected[1])>0 and len(executed)>0 and not failures
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
 for name,p in files.items():assert sha(p)==pre[name]['sha256']
 # Export actual artifacts and headers for review, never install them.
 package=out/'package';package.mkdir();items=[(p,'bin/'+name if name in ['transaction_test','rag3db_shell'] else 'lib/'+name) for name,p in files.items()]
 for root,label in [(source/'src/include','headers-source'),(build/'src/include','headers-generes')]:
  for p in root.rglob('*'):
   if p.is_file():items.append((p,str(Path(label)/p.relative_to(root))))
 for p in (build/'third_party').rglob('*.a'):items.append((p,str(Path('tiers')/p.relative_to(build/'third_party'))))
 assert sum(p.stat().st_size for p,_ in items)<512*1024**2
 package_files=[]
 for p,name in items:
  if time.monotonic()>=deadline:raise RuntimeError('budget export atteint')
  dst=package/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);h=sha(p);assert sha(dst)==h;package_files.append({'path':name,'bytes':p.stat().st_size,'sha256':h})
 write('manifest-final.json',{'source_commit':commit,'build_id':marker,'files':package_files,'native_build':True,'transaction_test_run':True,'distributed_install':False,'master_publication_authorized':False})
except BaseException as e:
 write('premier-echec.json',{'phase':phase,'type':type(e).__name__,'message':str(e),'retry':False,'source_commit':commit});raise
