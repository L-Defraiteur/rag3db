#!/usr/bin/env bash
set -euo pipefail
out="$HOME/.cache/rag3db-moteur-notes/ci-format18-74ad-01"
scratch="$HOME/.cache/rag3weaver-build/cx-ci-format18-74ad-01"
exec "$HOME/.cache/rag3weaver-build/poste" lourd systemd-run --user --wait --pipe \
 --unit=cx-coeur-ci-format18-74ad-01 --property=MemoryMax=34359738368 --property=MemorySwapMax=0 \
 --property=RuntimeMaxSec=2390 --property=TimeoutStopSec=10 --property=KillMode=control-group \
 --property=Nice=19 --property=IOSchedulingClass=idle \
 bwrap --unshare-user --unshare-net --ro-bind / / --proc /proc --dev /dev \
 --size 34359738368 --tmpfs "$scratch" --bind "$out" "$out" \
 /usr/bin/python3 "$out/cx-ci18-outer.py" "$scratch" "$out" \
 "$HOME/git_workspaces/rag3db-colonnes" "$out/recette.json" "$out/source.pack"
