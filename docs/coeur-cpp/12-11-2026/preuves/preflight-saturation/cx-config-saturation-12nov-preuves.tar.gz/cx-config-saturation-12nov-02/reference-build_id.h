// Généré par cmake/build_id.cmake à chaque bâti ; ne pas éditer.
#pragma once

#define RAG3DB_BUILD_ID "rag3db-build-29a7bc52aaf11e6204f9beafaffb154105417e13-Release-p12-v11-g17-s18-rcOFF-stOFF-asanOFF-tsanOFF-ubsanOFF"
