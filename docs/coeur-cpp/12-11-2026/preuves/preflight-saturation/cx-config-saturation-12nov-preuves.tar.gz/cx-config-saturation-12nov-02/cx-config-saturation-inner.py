import hashlib,json,os,shlex,subprocess,sys,time
from pathlib import Path
source,build,out,reference,recipe=map(Path,sys.argv[1:6]);deadline=float(sys.argv[6])
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,obj):(out/name).write_text(json.dumps(obj,indent=2)+'\n')
def run(argv,name):
 p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=max(1,deadline-time.monotonic()))
 if len(p.stdout)>16*1024**2:raise RuntimeError('sortie trop grande')
 (out/name).write_bytes(p.stdout)
 if p.returncode:raise RuntimeError(f'{name} code {p.returncode}')
 return p.stdout
assert os.statvfs(source).f_flag & os.ST_RDONLY
assert os.statvfs(reference).f_flag & os.ST_RDONLY
assert not(os.statvfs(build).f_flag & os.ST_RDONLY)
os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ['GIT_ALLOW_PROTOCOL']='';os.environ['CCACHE_DISABLE']='1'
v=json.loads(recipe.read_text());argv=[s.replace('{private_source}',str(source)).replace('{private_build}',str(build)) for s in v['build']['configure_argv']]
argv+=['-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DFETCHCONTENT_UPDATES_DISCONNECTED=ON','-DAUTO_UPDATE_GRAMMAR=OFF','-DCCACHE_PROGRAM:FILEPATH=','-DSINGLE_THREADED=OFF','-DENABLE_MALLOC_BUFFER_MANAGER=OFF','-DUSE_STD_FORMAT=OFF']
# Historical cache stores OFF for optional log2 overrides. Leave these overrides
# unset too; compare effective generated constants rather than invent cache sizes.
write('configure-argv.json',argv)
run(argv,'configure.log')
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
commands=json.loads((build/'compile_commands.json').read_text());old=json.loads((reference/'compile_commands.json').read_text())
oldsource=reference.parent.parent

def norm(item,root,binary):
 f=Path(item['file']);args=item.get('arguments') or shlex.split(item['command']);clean=[];i=0
 while i<len(args):
  t=args[i]
  if t in ['-o','-c','-MF','-MT']:i+=2;continue
  if t=='-MD':i+=1;continue
  clean.append(t.replace(str(binary),'<BUILD>').replace(str(root),'<SOURCE>'));i+=1
 return str(f.relative_to(root)),clean

def inventory(items,root,binary):
 return dict(norm(i,root,binary) for i in items if Path(i['file']).is_relative_to(root))
a=inventory(old,oldsource,reference);b=inventory(commands,source,build)
added=sorted(b.keys()-a.keys());removed=sorted(a.keys()-b.keys());differences={k:{'reference':a[k],'candidate':b[k]} for k in a.keys()&b.keys() if a[k]!=b[k]}
missing_sources=[str(i['file']) for i in commands if not Path(i['file']).is_file()]
missing_includes=[]
for i in commands:
 args=i.get('arguments') or shlex.split(i['command'])
 for t in args:
  if t.startswith('-I') and not Path(t[2:]).is_dir():missing_includes.append(t[2:])
# New diagnostic TU must use the exact common-core flags of its neighbour.
new_tu='src/common/private_saturation_capture.cpp';reference_tu='src/common/test_hooks.cpp'
core_abi_flags_equal=b.get(new_tu)==b.get(reference_tu)
# -c/-o stripped, so equality also strips source spelling entirely.
report={'added_TUs':added,'removed_TUs':removed,'changed_commands':differences,'candidate_count':len(commands),'reference_count':len(old),'core_counts':{'reference':sum(k.startswith('src/') for k in a),'candidate':sum(k.startswith('src/') for k in b)},'new_common_flags_equal_test_hooks':core_abi_flags_equal,'missing_sources':missing_sources,'missing_include_directories':sorted(set(missing_includes)),'transitive_dependency_limit':'no native compile, no fresh depfile, no claim of exhaustive header resolution'}
write('comparaison-commandes.json',report)
# Inventory dry-run lists only. -t commands does not build or execute commands.
for target in ['concurrence_test','rag3db_vector_extension','rag3db_geo_extension']:
 run(['ninja','-C',str(build),'-t','commands',target],f'ninja-{target}-commands.txt')

def cache(p):
 d={}
 for line in p.read_text().splitlines():
  if line and not line.startswith(('#','//')) and '=' in line and ':' in line.split('=',1)[0]:
   k,value=line.split('=',1);d[k.split(':',1)[0]]=value
 return d
ca,cb=cache(reference/'CMakeCache.txt'),cache(build/'CMakeCache.txt')
keys=['CMAKE_BUILD_TYPE','CMAKE_CXX_COMPILER','BUILD_TESTS','BUILD_EXTENSION_TESTS','BUILD_SHARED_LIBS','BUILD_EXTENSIONS','ENABLE_RUNTIME_CHECKS','SINGLE_THREADED','ENABLE_ADDRESS_SANITIZER','ENABLE_THREAD_SANITIZER','ENABLE_UBSAN','ENABLE_MALLOC_BUFFER_MANAGER','ENABLE_LTO','ENABLE_BACKTRACES','USE_STD_FORMAT','RAG3DB_PAGE_SIZE_LOG2','RAG3DB_VECTOR_CAPACITY_LOG2','RAG3DB_NODE_GROUP_SIZE_LOG2','RAG3DB_MAX_SEGMENT_SIZE_LOG2']
cache_comparison={k:{'reference':ca.get(k),'candidate':cb.get(k),'equal':ca.get(k)==cb.get(k)} for k in keys}
headers={}
for name in ['system_config.h','build_id.h']:
 p=build/'src/include/common'/name;q=reference/'src/include/common'/name
 if not p.is_file():
  assert name == 'build_id.h'
  headers[name]={'candidate_generated':False,'reference':q.read_text(),'equal':None,'reason':'custom build target, NOT executed during configure/preflight'}
  (out/('reference-'+name)).write_bytes(q.read_bytes())
  continue
 headers[name]={'reference':q.read_text(),'candidate':p.read_text(),'equal':p.read_bytes()==q.read_bytes()}
 (out/('private-'+name)).write_bytes(p.read_bytes());(out/('reference-'+name)).write_bytes(q.read_bytes())
write('comparaison-abi.json',{'cache':cache_comparison,'generated_headers':headers,'expected_non_ABI_changes':['BuildID source6bfba5b4c vs historical reference','new private diagnostic TU and source hooks','FETCHCONTENT fully disconnected; grammar update OFF; ccache disabled'],'native_abi_test':False})
for name in ['CMakeCache.txt','compile_commands.json','build.ninja']:
 (out/name).write_bytes((build/name).read_bytes())
for name in ['CMakeCache.txt','compile_commands.json']:(out/('reference-'+name)).write_bytes((reference/name).read_bytes())
run(['/usr/bin/c++','--version'],'compiler-version.txt');run(['cmake','--version'],'cmake-version.txt');run(['ninja','--version'],'ninja-version.txt')
write('preflight-status.json',{'configured':True,'native_build':False,'scenario_run':False,'added_TUs_expected':added==[new_tu],'removed_empty':not removed,'command_changes_empty':not differences,'new_common_flags_match':core_abi_flags_equal,'missing_sources':missing_sources,'missing_includes':sorted(set(missing_includes)),'abi_cache_equal':all(x['equal'] for x in cache_comparison.values()),'effective_system_config_equal':headers['system_config.h']['equal'],'source_readonly':True,'targets_commands_only':True,'build_authorized':False})
write('SHA256.json',{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='SHA256.json'})
