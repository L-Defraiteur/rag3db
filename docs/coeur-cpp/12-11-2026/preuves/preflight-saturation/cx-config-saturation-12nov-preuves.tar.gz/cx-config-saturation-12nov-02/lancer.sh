#!/usr/bin/env bash
set -euo pipefail
out="$HOME/.cache/rag3db-moteur-notes/annulation/cx-config-saturation-12nov-02"
scratch="$HOME/.cache/rag3weaver-build/cx-config-saturation-12nov-02"
exec "$HOME/.cache/rag3weaver-build/poste" lourd systemd-run --user --wait --pipe \
 --unit=cx-coeur-config-saturation-12nov-02 \
 --property=MemoryMax=8589934592 --property=MemorySwapMax=0 \
 --property=RuntimeMaxSec=290 --property=TimeoutStopSec=5 \
 --property=KillMode=control-group --property=Nice=19 --property=IOSchedulingClass=idle \
 bwrap --unshare-user --unshare-net --ro-bind / / --proc /proc --dev /dev \
 --size 2147483648 --tmpfs "$scratch" --bind "$out" "$out" \
 /usr/bin/python3 "$out/cx-config-saturation.py" "$scratch" "$out" \
 "$HOME/git_workspaces/rag3db-colonnes" "$out/recette-revue.json" "$out/source.pack"
