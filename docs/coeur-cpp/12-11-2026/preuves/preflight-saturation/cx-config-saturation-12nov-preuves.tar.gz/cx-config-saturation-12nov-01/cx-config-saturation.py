import hashlib,json,os,shlex,shutil,subprocess,sys,time
from pathlib import Path
scratch,output,reference,recipe,pack=map(Path,sys.argv[1:])
start=time.monotonic();deadline=start+285
source=scratch/'source';build=scratch/'build';tmp=scratch/'tmp';expected='6bfba5b4c'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,obj):(output/name).write_text(json.dumps(obj,indent=2)+'\n')
def run(argv,name,cwd=None):
 remaining=deadline-time.monotonic()
 if remaining<=0:raise RuntimeError('budget configure/preflight atteint')
 proc=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=remaining)
 if len(proc.stdout)>16*1024**2:raise RuntimeError('sortie preflight depasse 16Mio')
 (output/name).write_bytes(proc.stdout)
 if proc.returncode:raise RuntimeError(f'{name}: code {proc.returncode}')
 return proc.stdout
cg=next(x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
cgp=Path('/sys/fs/cgroup')/cg.lstrip('/')
limits={'cgroup':cg,'memory.max':(cgp/'memory.max').read_text().strip(),'memory.swap.max':(cgp/'memory.swap.max').read_text().strip(),'scratch_bytes':os.statvfs(scratch).f_blocks*os.statvfs(scratch).f_frsize,'routes':Path('/proc/net/route').read_text(),'started_monotonic':start}
write('limites.json',limits)
assert limits['memory.max']=='8589934592' and limits['memory.swap.max']=='0'
assert limits['scratch_bytes']==2147483648 and len(limits['routes'].splitlines())==1
assert os.statvfs(reference).f_flag & os.ST_RDONLY
assert not any(scratch.iterdir())
tmp.mkdir();build.mkdir();os.environ['TMPDIR']=str(tmp);os.environ['CCACHE_DISABLE']='1';os.environ['GIT_OPTIONAL_LOCKS']='0';os.environ['GIT_ALLOW_PROTOCOL']='file';os.environ['GIT_TERMINAL_PROMPT']='0'
run(['git','clone','--shared','--no-checkout',str(reference),str(source)],'staging-clone.log')
with pack.open('rb') as stream:
 subprocess.run(['git','-C',str(source),'unpack-objects','-q'],stdin=stream,check=True,timeout=max(1,deadline-time.monotonic()))
run(['git','-C',str(source),'checkout','--detach',expected],'staging-checkout.log')
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit.startswith(expected)
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'])
for ext in ['vector','geo']:(source/'extension'/ext/'build').mkdir()
# Script of this file owns staging only. Configure controller runs in a nested
# mount namespace: source RO with exactly the two extension output exceptions.
cmd=['bwrap','--unshare-user','--unshare-net','--ro-bind','/','/','--proc','/proc','--dev','/dev','--ro-bind',str(source),str(source),'--bind',str(build),str(build),'--bind',str(tmp),str(tmp),'--bind',str(output),str(output)]
for ext in ['vector','geo']:
 d=str(source/'extension'/ext/'build');cmd+=['--bind',d,d]
cmd+=['--chdir',str(source),'/usr/bin/python3',str(output/'cx-config-saturation-inner.py'),str(source),str(build),str(output),str(reference/'build/moteur'),str(recipe),str(deadline)]
run(cmd,'preflight-inner.log')
write('fin.json',{'elapsed_s':time.monotonic()-start,'source_commit':commit,'pack_sha256':sha(pack),'no_native_build':True,'scratch_used_bytes':(os.statvfs(scratch).f_blocks-os.statvfs(scratch).f_bfree)*os.statvfs(scratch).f_frsize})
